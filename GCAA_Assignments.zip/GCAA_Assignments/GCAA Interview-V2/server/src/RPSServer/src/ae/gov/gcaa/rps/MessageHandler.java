package ae.gov.gcaa.rps;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import ae.gov.gcaa.rps.commons.Message;
import ae.gov.gcaa.rps.commons.Utils;
import ae.gov.gcaa.rps.game.RockPaperScissors;

/**
 * @author Zubair Handles incoming message from client
 */
public class MessageHandler {

	private List<ServerSocketEndPoint> clients = null;
	private ServerSocketEndPoint currentUser = null;
	private Message message = null;

	public MessageHandler(Message message, List<ServerSocketEndPoint> socketClients, ServerSocketEndPoint currentUser) {
		this.clients = socketClients;
		this.message = message;
		this.currentUser = currentUser;
	}

	/**
	 * Handles message pass the message to right receiver
	 */
	public void handle() {
		if ("join".equalsIgnoreCase(this.message.getType())) {
			if (isUserAlreadyExists(this.message.getSender())) {
				currentUser.sendMessage(
						new Message("multisession", "server", "Use different user to join", this.message.getSender()));
				return;
			}
			this.currentUser.setUsername(this.message.getSender());
			String sender = this.message.getSender() + "";
			String[] teamSender = sender.split("/");
			this.currentUser.setUsername(teamSender[1]);
			this.currentUser.setTeam(teamSender[0]);
			String responseMessage = getUsers() + "::" + Utils.SCORE.get("TEAMA") + "`" + Utils.SCORE.get("TEAMB");
			Message m = new Message("init", "server", responseMessage, sender);
			this.currentUser.sendMessage(m);
			notifyUsers("userjoined", sender);
		} else if ("broadcast".equalsIgnoreCase(this.message.getType())) {
			for (ServerSocketEndPoint client : clients) {
				client.sendMessage(message);
			}
		} else if ("close".equalsIgnoreCase(this.message.getType())) {
			clients.remove(currentUser);
			notifyUsers("userleft", currentUser.getTeam() + "/" + currentUser.getUsername());
			System.out.println(this.message.getSender() + " has been logout");
		} else if ("private".equalsIgnoreCase(this.message.getType())) {
			String recipient = this.message.getRecipient();
			if (!"<ALL>".equalsIgnoreCase(recipient)) {
				ServerSocketEndPoint client = findMessageReciever(this.message.getRecipient());
				if (client != null) {
					client.sendMessage(message);
				}
			} else {
				sendToAllUsers(message);
			}
		} else if ("move".equalsIgnoreCase(this.message.getType())) {
			String theMove = (this.message.getContent() + "").toUpperCase();
			theMove = theMove.replace("@MOVE", "");
			String team = currentUser.getTeam();
			String otherTeam = "Team A".equalsIgnoreCase(team) ? "Team B" : "Team A";
			if (otherTeamHasActiveUsers(otherTeam)) {
				String teamAMove = "";
				String teamBMove = "";
				if ("team A".equalsIgnoreCase(team)) {
					Utils.teamAMove = theMove;
					teamAMove = theMove;
					teamBMove = Utils.teamBMove;
				} else if ("team B".equalsIgnoreCase(team)) {
					Utils.teamBMove = theMove;
					teamBMove = theMove;
					teamAMove = Utils.teamAMove;
				}
				if (!Utils.isNullOrEmptyString(teamAMove) && !Utils.isNullOrEmptyString(teamBMove)) {
					System.out.println(
							"Both teams have made move Team A [" + teamAMove + "] and Team B Move [" + teamBMove + "]");
					RockPaperScissors rps = new RockPaperScissors();
					int result = rps.getWinner(teamAMove, teamBMove);
					// reset moves
					Utils.teamBMove = "";
					Utils.teamAMove = "";
					String messageContent = "Team A selected [" + teamAMove + "] and Team B selected [" + teamBMove
							+ "] so ";
					if (1 == result) {
						messageContent = messageContent + " Team A WIN :)";
						Utils.SCORE.put("TEAM A", Utils.SCORE.get("TEAM A")+1);
					} else if (-1 == result) {
						messageContent = messageContent + " Team B WIN :)";
						Utils.SCORE.put("TEAM B", Utils.SCORE.get("TEAM B")+1);
					} else {
						messageContent = messageContent + " its tie == ";
					}
					sendToAllUsers(messageContent+"::"+Utils.SCORE.get("TEAM A")+"`"+Utils.SCORE.get("TEAM B"));
				} else {
					sendToTeam("@Move" + theMove, team);
					sendToTeam(team + " has made a move", otherTeam);
				}
			} else {
				String computerMove = Utils.computerMoves[ThreadLocalRandom.current().nextInt(0, 3)];
				RockPaperScissors rps = new RockPaperScissors();
				int result = rps.getWinner(theMove, computerMove);
				String messageContent = "You selected [" + theMove + "] computer pick [" + computerMove + "] so ";
				if (1 == result) {
					messageContent = messageContent + " you WIN :)";
				} else if (-1 == result) {
					messageContent = messageContent + " you LOSE :(";
				} else {
					messageContent = messageContent + " its tie = ";
				}
				currentUser.sendMessage(
						new Message("rpsresult", "server", messageContent, team + "/" + currentUser.getUsername()));
			}
		}
	}

	private boolean isUserAlreadyExists(String username) {
		for (ServerSocketEndPoint client : clients) {
			if ((client.getUsername() + "").equalsIgnoreCase(username)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param receiver
	 * @return searches and returns client thread to pass message
	 */
	private ServerSocketEndPoint findMessageReciever(String receiver) {
		ServerSocketEndPoint messageClient = null;
		for (ServerSocketEndPoint client : clients) {
			if (receiver.equalsIgnoreCase(client.getTeam() + "/" + client.getUsername())) {
				messageClient = client;
				break;
			}
		}
		if (messageClient == null) {
			System.out.println(receiver + ": has left");
		}
		return messageClient;
	}

	private String getUsers() {
		StringBuilder users = new StringBuilder();
		for (ServerSocketEndPoint client : clients) {
			users.append(client.getTeam() + "/" + client.getUsername() + "`");
		}
		return users.toString();
	}

	private void notifyUsers(String joinleft, String username) {
		Message m = new Message(joinleft, "server", username, "<ALL>");
		for (ServerSocketEndPoint client : clients) {
			client.sendMessage(m);
		}
	}

	private boolean otherTeamHasActiveUsers(String otherTeam) {
		for (ServerSocketEndPoint client : clients) {
			if (otherTeam.equalsIgnoreCase(client.getTeam())) {
				return true;
			}
		}
		return false;
	}

	private void sendToAllUsers(String message) {
		for (ServerSocketEndPoint client : clients) {
			client.sendMessage(
					new Message("rpsresult", "server", message, client.getTeam() + "/" + client.getUsername()));
		}
	}

	private void sendToAllUsers(Message message) {
		for (ServerSocketEndPoint client : clients) {
			client.sendMessage(message);
		}
	}

	private void sendToTeam(String message, String team) {
		for (ServerSocketEndPoint client : clients) {
			if (team.equalsIgnoreCase(client.getTeam())) {
				client.sendMessage(new Message("private", currentUser.getTeam() + "/" + currentUser.getUsername(),
						message, client.getTeam() + "/" + client.getUsername()));
			}
		}
	}
}
