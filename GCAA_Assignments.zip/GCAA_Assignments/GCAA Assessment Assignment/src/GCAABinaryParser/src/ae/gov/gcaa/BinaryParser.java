package ae.gov.gcaa;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 * @author Zubair Parses the binary file
 */
public class BinaryParser {

	public static final List<Integer> fieldLength = new ArrayList<>(
			Arrays.asList(2, 1, 3, 1, 2, 2, 3, 5, 4, 1, 3, 2, 1, 1));

	/**
	 * @param _file
	 * @return return binary string for the file
	 */
	private static List<String> getFileBinary(File _file) {
		FileInputStream inputStream = null;
		List<String> binaries = new ArrayList<String>();
		try {
			byte[] buffer = new byte[1];
			inputStream = new FileInputStream(_file);
			// read fills buffer with data and returns
			// the number of bytes read (which of course
			// may be less than the buffer size, but
			// it will never be more).
			int total = 0;
			int nRead = 0;
			while ((nRead = inputStream.read(buffer)) != -1) {
				String databyte = String.format("%8s", Integer.toBinaryString(buffer[0] & 0xFF)).replace(' ', '0');
				binaries.add(databyte);
			}
			System.out.println("Read " + total + " bytes");
			System.out.println("Data [" + binaries.toString() + "]");
		} catch (FileNotFoundException ex) {
			System.err.println("Unable to open file [" + _file.getName() + "]");
		} catch (IOException ex) {
			System.out.println("Error reading file [" + _file.getName() + "]");
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					System.err.println("Cannot close file stream because:" + e.getMessage());
				}
			}
		}
		return binaries;
	}

	private static void parse(List<String> bytes) throws Exception {
		int pointer = 3; // Skip cat and len
		System.out.println("Bytes:" + bytes.size());
		while (pointer < bytes.size()) {
			int bytePointer = pointer;
			String dataByte = bytes.get(bytePointer++);
			List<String> fspec = new ArrayList<String>();
			while (dataByte.charAt(7) != '0') {
				fspec.add(dataByte);
				dataByte = bytes.get(bytePointer++);
			}
			fspec.add(dataByte); // because last byte is also FSPEC
			System.out.println("FSPEC size:" + fspec.size());
			System.out.print("FSPEC :");
			for (int j = 0; j < fspec.size(); j++) {
				System.out.print(fspec.get(j) + (j + 1 != fspec.size() ? ", " : ""));
			}
			System.out.println();

			int fieldPointer = 0;
			for (int j = 0; j < fspec.size(); j++) {
				for (int k = 0; k < 7; k++) {

					int currentFieldLength = 1; // assume if length not given
												// then its 1
					if (fieldPointer < fieldLength.size()) {
						currentFieldLength = fieldLength.get(fieldPointer);
					}

					if (fspec.get(j).charAt(k) == '1') {
						System.out.print("Field " + (fieldPointer + 1) + ":");
						int fieldStartIndex = bytePointer;
						// int fieldEndIndex = (bytePointer +
						// currentFieldLength) > stream.size() ? stream.size() :
						// (bytePointer + currentFieldLength);
						int fieldEndIndex = bytePointer + currentFieldLength;
						for (int l = fieldStartIndex; l < fieldEndIndex; l++) {
							try {
								System.out.print(bytes.get(l) + (l + 1 != fieldEndIndex ? "," : ""));
							} catch (Exception e) {
								String errorMsg = "End of file binary, please check with owners some of the data bytes are missing in the file, Internal ERROR:"
										+ e.getMessage();
								System.err.println(errorMsg);
								throw new Exception(errorMsg);
							}
							bytePointer++;
						}
						System.out.println();
					}
					fieldPointer++;
				}
			}
			pointer = bytePointer;
		}
	}

	public static void main(String[] args) throws Exception {

		String filename = "";
		Scanner scanner = new Scanner(System.in);
		if (args.length > 0) {
			System.out.println("File loading from command line argument");
			filename = args[0];
		} else {
			System.out.println("Please enter full filepath to parse");
			filename = scanner.nextLine();
		}
		File _file = new File(filename);
		if (_file.exists() && !_file.isDirectory()) {
			System.out.println("File [" + filename + "] found:" + (_file.length() / (1024)) + " KBs");
			System.out.println("Do you want to continue [Y/N]?");
			String continueOrNot = scanner.nextLine() + "";
			if ("Y".equalsIgnoreCase(continueOrNot.trim())) {
				List<String> fileBinary = getFileBinary(_file);
				parse(fileBinary);
			} else {
				System.out.println("Skipping parse!");
			}
			scanner.close();
		} else {
			System.out.println("File [" + filename + "] does not exist or is a directory!");
			scanner.close();
		}

	}

}
