package ae.gov.gcaa.rps;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.JOptionPane;

import ae.gov.gcaa.rps.commons.Message;
import ae.gov.gcaa.rps.ui.RPSClient;

/**
 * @author Zubair Client class for server to hold information of clients and
 *         exchange messages
 *
 */
public class ClientSocketEndPoint implements Runnable {

	private String username = "";
	private ObjectInputStream streamIn = null;
	private ObjectOutputStream streamOut = null;

	private Socket socket = null;
	private RPSClient ui = null;
	private String id = "";
	private int clientPort = -1;

	/**
	 * main constructor accepts the socket and username for current connected
	 * client
	 * 
	 * @param socket
	 * @param username
	 */
	public ClientSocketEndPoint(RPSClient client,String username) {
		this.ui = client;
		this.socket = this.ui.getSocket();
		this.clientPort = socket.getPort();
		this.id = clientPort + ":" + socket.toString();
		System.out.println(this.id + ": has been initialsed");
		this.username = username;
	}

	/**
	 * start communication
	 */
	public void start() {
		try {
			init();
			System.out.println(this.username + ":Successfully intialized");
			sendMessage(new Message("join", this.username, "Request to Join", "server"));
			boolean keepRunning = true;
			while (keepRunning) {
				try {
					Message msg = (Message) this.streamIn.readObject();
					System.out.println("Incoming Message: " + msg.toString());
					MessageHandler handler = new MessageHandler(msg, ui);
					handler.handle();
				} catch (Exception e) {
					JOptionPane.showMessageDialog(this.ui, "Error:" + e.getMessage());
					keepRunning = false;
				}
			}
		} catch (IOException e) {
			System.err.println(this.username + "Cannot initialzed required resources for client");
			e.printStackTrace();
		}
		try {
			end();
		} catch (IOException e) {
			System.out.println(this.username + ": Cannot end cleaning because:" + e.getMessage());
		}
	}

	/**
	 * @throws IOException
	 *             function initializes the streams to receive and pass messages
	 *             to and from server
	 */
	public void init() throws IOException {
		this.streamOut = new ObjectOutputStream(this.socket.getOutputStream());
		this.streamOut.flush();
		this.streamIn = new ObjectInputStream(this.socket.getInputStream());
	}

	/**
	 * @throws IOException
	 *             closes all resources for this client
	 */
	public void end() throws IOException {
		sendMessage(new Message("close", this.username, "good bye", "server"));
		if (this.socket != null) {
			this.socket.close();
		}
		if (this.streamIn != null)
			this.streamIn.close();
		if (this.streamOut != null)
			this.streamOut.close();

		System.out.println("connection ended for " + id);
	}

	/**
	 * @param msg
	 *            Sends the message
	 */
	public void sendMessage(Message message) {
		try {
			streamOut.writeObject(message);
			streamOut.flush();
		} catch (IOException ioException) {
			System.out.println("Client::Cannot send message because:" + ioException.getMessage());
		}
	}

	@Override
	public void run() {
		start();

	}

}
