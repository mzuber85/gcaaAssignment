1) JDK1.8 or greater must be installed in the target system
2) JAVA_HOME environment variable must be set
3) Start RPSClient.jar file
4) Enter server and port and click connect, default/prefilled for server is 'localhost' and port '6666'
5) Enter username and Team and click join, default/prefilled for username is 'Zubair' and Team 'TeamA'
6) Start Messaging
	i) @MoveR,@MoveP,@MoveS in message is considered as game move for Rock, Paper and Scissor respectively
7) if only one team's player are available then move will be considered against server and server will make its move and calculate who is winner and give back the result
8) src folder contains source code for the client