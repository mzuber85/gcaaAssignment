package ae.gov.gcaa.rps.commons;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author Zubair
 *Utility functions class
 */
public class Utils {

	public static final Map<String, Integer> SCORE = createMap();
	public static String teamAMove = "";
	public static String teamBMove = "";
	public static int gameNumber = 0;
	public static final String[] computerMoves = new String[]{"R","P","S"};
    private static Map<String, Integer> createMap()
    {
        Map<String,Integer> myMap = new LinkedHashMap<String,Integer>();
        myMap.put("TEAM A", 0);
        myMap.put("TEAM B", 0);
        myMap.put("TIES", 0);
        return myMap;
    };
	
	/**
	 * @param s
	 * @return
	 */
	public static boolean isNullOrEmptyString(String s) {
		return s == null || "".equals(s.trim()) || "null".equalsIgnoreCase(s.trim());
	}
	/**
	 * @param s
	 * @return
	 */
	public static String fixNullString(String s) {
		return isNullOrEmptyString(s)?"":s;
	}
	public static void main0(String[] args) {
		String[] toCheck = new String[]{null,""," ","null","NUll"," null ","notNUll"};
		for (String string : toCheck) {
			System.out.println(string+"::"+isNullOrEmptyString(string));
		}
	}
	
}
