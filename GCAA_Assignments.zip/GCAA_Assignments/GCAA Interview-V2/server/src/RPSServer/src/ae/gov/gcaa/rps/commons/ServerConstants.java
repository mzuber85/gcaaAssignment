package ae.gov.gcaa.rps.commons;

public interface ServerConstants {

	int SERVER_PORT = 6666;
	
	int TOTAL_CLIENTS = 50;
}
