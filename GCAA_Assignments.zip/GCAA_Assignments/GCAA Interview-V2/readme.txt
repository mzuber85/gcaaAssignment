see server folder first and then client folder
docs folder contains SOP document, usecase and sequence diagrams

