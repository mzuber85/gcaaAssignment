package ae.gov.gcaa.rps.game;

import java.util.concurrent.ThreadLocalRandom;

import ae.gov.gcaa.rps.commons.Utils;

/**
 * @author Zubair Game class will determine the winner
 */
public class RockPaperScissors {

	/**
	 * @param playerAOption
	 * @param playerBOption
	 * @return int 1 Player A is winner -1 Player B is winner 0 tie
	 */
	public int getWinner(String playerAOption, String playerBOption) {
		RPSMove playerAMove = playerOptionToMove(playerAOption);
		RPSMove playerBMove = playerOptionToMove(playerBOption);
		int winner = playerAMove.compareMoves(playerBMove);
		System.out.println(playerAOption + ":" + playerBOption + "::::" + winner);
		return winner;
	}

	/**
	 * @param playerOption
	 * @return from user option string to system internal enum
	 */
	private RPSMove playerOptionToMove(String playerOption) {
		playerOption = Utils.fixNullString(playerOption).toUpperCase();
		RPSMove move = RPSMove.INVALID;
		if (playerOption.startsWith("R")) {
			move = RPSMove.ROCK;
		} else if (playerOption.startsWith("P")) {
			move = RPSMove.PAPER;
		} else if (playerOption.startsWith("S")) {
			move = RPSMove.SCISSORS;
		}
		return move;
	}

	public static void main0(String[] args) {
		RockPaperScissors rps = new RockPaperScissors();
		String[] options = new String[] { "Rock", "Paper", "Scissors" };
		for (int i = 0; i < 10; i++) {
			int rand = ThreadLocalRandom.current().nextInt(0, 3);
			rps.getWinner(options[rand], options[ThreadLocalRandom.current().nextInt(0, 3)]);
		}

	}

}
