package ae.gov.gcaa.rps.commons;

public interface ClientConstants {

	int SERVER_PORT = 6666;
	String SERVER_HOST = "localhost";
	
}
