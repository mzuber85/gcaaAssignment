package ae.gov.gcaa.rps.game;

/**
 * @author Zubair
 *ENUM for meaningful Move names and to determine winner among the two MOVES
 */
public enum RPSMove {

	ROCK, PAPER, SCISSORS,INVALID;

	/**
	 * Compares this move with moveToCompare:: determines a tie, a win, or a
	 * lost.
	 * 
	 * @param moveToComapre
	 *            move to compare with
	 * @return 1 if this move beats the moveToComapre, -1 if this move loses to
	 *         the moveToComapre, 0 if these moves tie
	 */
	public int compareMoves(RPSMove moveToComapre) {
		// Tie
		if (this == moveToComapre)
			return 0;

		switch (this) {
		case ROCK:
			return (moveToComapre == SCISSORS ? 1 : -1);
		case PAPER:
			return (moveToComapre == ROCK ? 1 : -1);
		case SCISSORS:
			return (moveToComapre == PAPER ? 1 : -1);
		case INVALID:
			return -1;
		}
		return 0;
	}
}
