1) JDK1.8 or greater must be installed in the target system
2) JAVA_HOME environment variable must be set
3) Server is using port 6666 so it must be avaiable
4) run execute.bat file 
5) Server is ready to accept connections 
6) src folder constains soruce code for the server