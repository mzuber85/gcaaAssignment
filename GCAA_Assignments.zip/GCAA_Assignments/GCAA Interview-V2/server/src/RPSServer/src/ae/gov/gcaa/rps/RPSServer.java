package ae.gov.gcaa.rps;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import ae.gov.gcaa.rps.commons.ServerConstants;

/**
 * @author Zubair Main server class starts the server and accept connection from
 *         clients
 */
public class RPSServer {

	/**
	 * main server socket used to accept new connections
	 */
	private ServerSocket serverSocket = null;
	private List<ServerSocketEndPoint> socketClients = new ArrayList<>(ServerConstants.TOTAL_CLIENTS);

	/**
	 * start up at port ServerConstants.SERVER_PORT
	 */
	public void startup() {

		try {
			// create server socket where client can connect
			this.serverSocket = new ServerSocket(ServerConstants.SERVER_PORT, ServerConstants.TOTAL_CLIENTS);
			
			System.out.println("Server has been started and listening connection request at port:"
					+ this.serverSocket.getLocalPort());
		} catch (IOException ioException) {
			System.err.println("Fail to startup server because:" + ioException.getMessage());
		}
		// server socket has created ready to accept connections from clients 
		if (this.serverSocket != null) {
			while (true) {
				try {
					if (socketClients.size() <= ServerConstants.TOTAL_CLIENTS) {
						Socket socket = this.serverSocket.accept();
						int clientPort = socket.getPort();
						// new connection (client) connected start a thread for this client
						ServerSocketEndPoint client = new ServerSocketEndPoint(socket, this.socketClients);
						String threadName = clientPort + ":" + socket.toString();
						Thread clientThread = new Thread(client, threadName);
						this.socketClients.add(client);
						clientThread.start();
						System.out.println(threadName + " has been created and started for client");
					} else {
						System.out
								.println("Cannot connect to more than [" + ServerConstants.TOTAL_CLIENTS + "] clients");
					}
				} catch (IOException ioException) {
					System.err.println("Cannot accept connection because:" + ioException.getMessage());
					ioException.printStackTrace();
					shutdown();
				}
			}
		}
	}

	/**
	 * shutdown the server
	 */
	public void shutdown() {
		if (this.serverSocket != null) {
			try {
				this.serverSocket.close();
			} catch (IOException e) {
				System.err.println("Cannot close server socket because:" + e.getMessage());
			}
		}
		System.exit(1);
	}

	public static void main(String[] args) {
		RPSServer server = new RPSServer();
		server.startup();
	}

}
