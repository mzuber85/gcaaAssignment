package ae.gov.gcaa.rps;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

import ae.gov.gcaa.rps.commons.Message;

/**
 * @author Zubair Client class for server to hold information of clients and
 *         exchange messages
 *
 */
public class ServerSocketEndPoint implements Runnable {

	private String username = "";
	private String team = "";
	private ObjectInputStream streamIn = null;
	private ObjectOutputStream streamOut = null;

	private Socket socket = null;
	private List<ServerSocketEndPoint> socketClients = null;
	private String id = "";
	private int clientPort = -1;

	/**
	 * main constructor accepts the socket and username for current connected
	 * client
	 * 
	 * @param socket
	 * @param username
	 */
	public ServerSocketEndPoint(Socket socket, List<ServerSocketEndPoint> socketClients) {
		this.socket = socket;
		this.clientPort = socket.getPort();
		this.id = clientPort + ":" + socket.toString();
		this.socketClients = socketClients;
		System.out.println(this.id + ": has been initialsed");
	}

	@Override
	public void run() {
		try {
			init();
			System.out.println(this.username + ":Successfully intialized");
			boolean keepRunning = true;
			sendMessage(new Message("message", "server", "you are connected", ""));
			while (keepRunning) {
				try {
					Message msg = (Message) this.streamIn.readObject();
					MessageHandler msgHandler = new MessageHandler(msg, socketClients, this);
					msgHandler.handle();
					System.out.println("Incoming Message: " + msg.toString());
				} catch (Exception e) {
					System.err.println(e.getMessage());
					e.printStackTrace();
					keepRunning = false;
				}
			}
		} catch (IOException e) {
			System.err.println(this.username + "Cannot initialzed required resources for client");
			e.printStackTrace();
		}
		try {
			end();
		} catch (IOException e) {
			System.out.println(this.username + ": Cannot end cleaning because:" + e.getMessage());
		}
	}

	/**
	 * @throws IOException
	 *             function initializes the streams to receive and pass messages
	 *             to and from server
	 */
	public void init() throws IOException {
		this.streamOut = new ObjectOutputStream(this.socket.getOutputStream());
		this.streamOut.flush();
		this.streamIn = new ObjectInputStream(this.socket.getInputStream());
	}

	/**
	 * @throws IOException
	 *             closes all resources for this client
	 */
	public void end() throws IOException {
		this.socketClients.remove(id);
		if (this.socket != null) {
			this.socket.close();
		}
		if (this.streamIn != null)
			this.streamIn.close();
		if (this.streamOut != null)
			this.streamOut.close();

		System.out.println("connection ended for " + id);
	}

	/**
	 * @param msg
	 *            Sends the message
	 */
	public void sendMessage(Message message) {
		try {
			streamOut.writeObject(message);
			streamOut.flush();
			System.out.println("Message sent to:" + message.getRecipient() + " by:" + message.getSender());
		} catch (IOException ioException) {
			System.out.println("Cannot send message because:" + ioException.getMessage());
		}
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}
	

}
