package ae.gov.gcaa.rps.commons;

import java.io.Serializable;

/**
 * @author Zubair
 * Message for client server communication
 *
 */
public class Message implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String type; // message can be one the types 1) broadcast 2) team 3) move 4) private 5) init 6) createteam 7) jointeam 
	private String sender; // sender of the message
	private String content; // message body
	private String recipient; // only relevant for private messages

	public Message(String type, String sender, String content, String recipient) {
		this.type = type;
		this.sender = sender;
		this.content = content;
		this.recipient = recipient;
	}

	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public String getSender() {
		return sender;
	}


	public void setSender(String sender) {
		this.sender = sender;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}


	public String getRecipient() {
		return recipient;
	}


	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}


	@Override
	public String toString() {
		return "{type='" + type + "', sender='" + sender + "', content='" + content + "', recipient='" + recipient
				+ "'}";
	}
	
	
}
