package ae.gov.gcaa.rps;

import ae.gov.gcaa.rps.commons.Message;
import ae.gov.gcaa.rps.ui.RPSClient;

/**
 * @author Zubair Handles incoming message from client
 */
public class MessageHandler {

	private RPSClient ui;
	private Message message = null;

	public MessageHandler(Message message, RPSClient ui) {
		this.ui = ui;
		this.message = message;
	}

	/**
	 * Handles message pass the message to right receiver
	 */
	public void handle() {
		String messagebody = this.message.getContent() + "";
		String messageType = this.message.getType() + "";
		String sender = this.message.getSender();
		if ("init".equalsIgnoreCase(messageType)) {
			if (messagebody.startsWith("ERROR:")) {
				this.ui.getJoinBtn().setEnabled(true);
				this.ui.showMessage(messagebody);
			} else {
				String[] initData = messagebody.split("::");
				String[] users = initData[0].split("`");
				for (String user : users) {
					this.ui.addUserInUI(user);
				}
				String[] scores = initData[1].split("`");
				this.ui.updateScores(scores[0], scores[1]);
			}
		} else if ("userleft".equalsIgnoreCase(messageType)) {
			this.ui.postOnHistoryBoard(messagebody + " has left");
			this.ui.removeUserInUI(messagebody);
		} else if ("userjoined".equalsIgnoreCase(messageType)) {
			this.ui.addUserInUI(messagebody);
			this.ui.postOnHistoryBoard(messagebody + " has joined");
		} else if ("multisession".equalsIgnoreCase(messageType)) {
			this.ui.postOnHistoryBoard(messagebody);
			this.ui.enableJoin(true);
		} else if ("rpsresult".equalsIgnoreCase(messageType)) {
			String msg[] = messagebody.split("::");
			this.ui.postOnHistoryBoard(sender + ">" + msg[0]);
			try {
				String[] scores = msg[1].split("`");
				this.ui.updateScores(scores[0], scores[1]);
			} catch (Exception e) {
			}
		} else if ("private".equalsIgnoreCase(messageType)) {
			this.ui.postOnHistoryBoard(sender + ">" + messagebody);
		}
	}

}
