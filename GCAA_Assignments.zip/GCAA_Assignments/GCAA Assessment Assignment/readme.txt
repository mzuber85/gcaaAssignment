1) JDK1.8 or greater must be installed in the target system
2) JAVA_HOME environment variable must be set
3) run execute.bat file 
4) System will ask for input file, give full file path of input file
5) After loading file system will ask to proceed with parsing of the file Type Y to continue and N to stop 